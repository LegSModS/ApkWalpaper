# Живые обои (Android)

## Способ 1 — собрать APK в облаке (без компьютера)
1. Создайте репозиторий на github.com и загрузите в него все файлы этого проекта (с папкой .github).
2. Вкладка Actions → "Build APK" → дождитесь зелёной галочки (3–5 минут).
3. Откройте завершённый запуск → внизу Artifacts → LiveWallpaper-apk (zip с app-debug.apk).
4. Распакуйте, установите APK на TECNO SPARK 20 (разрешите установку из неизвестных источников).

## Способ 2 — Android Studio
Открыть папку проекта → Build → Build APK(s).
Файл: app/build/outputs/apk/debug/app-debug.apk
