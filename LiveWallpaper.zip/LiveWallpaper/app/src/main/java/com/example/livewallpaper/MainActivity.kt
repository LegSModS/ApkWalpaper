package com.example.livewallpaper

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("prefs", Context.MODE_PRIVATE)
        val pad = (24 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, pad * 2, pad, pad)
            setBackgroundColor(Color.WHITE)
        }

        root.addView(TextView(this).apply {
            text = "Живые обои"
            textSize = 28f
            setTextColor(Color.BLACK)
        })
        root.addView(TextView(this).apply {
            text = "Выберите анимацию:"
            textSize = 16f
            setPadding(0, pad, 0, pad / 2)
        })

        val names = listOf("Волны", "Звёздное небо", "Пузырьки")
        val group = RadioGroup(this)
        names.forEachIndexed { i, n ->
            group.addView(RadioButton(this).apply {
                text = n
                textSize = 18f
                id = 100 + i
            })
        }
        group.check(100 + prefs.getInt("theme", 0))
        group.setOnCheckedChangeListener { _, id ->
            prefs.edit().putInt("theme", id - 100).apply()
        }
        root.addView(group)

        root.addView(Button(this).apply {
            text = "Установить обои"
            setOnClickListener { setWallpaper() }
        }, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = pad * 2 })

        root.addView(TextView(this).apply {
            text = "Если обои уже установлены, смена анимации применится при следующем включении экрана."
            textSize = 13f
            setPadding(0, pad, 0, 0)
        })

        setContentView(root)
    }

    private fun setWallpaper() {
        try {
            val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
                putExtra(
                    WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                    ComponentName(this@MainActivity, AnimatedWallpaperService::class.java)
                )
            }
            startActivity(i)
        } catch (e: Exception) {
            startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
        }
    }
}
