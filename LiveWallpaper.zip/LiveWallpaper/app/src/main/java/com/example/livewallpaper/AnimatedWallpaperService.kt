package com.example.livewallpaper

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

class AnimatedWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = WallEngine()

    inner class WallEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val path = Path()
        private var visible = false
        private var theme = 0
        private var startTime = SystemClock.uptimeMillis()
        private var lastFrame = startTime

        // звёзды
        private val starX = FloatArray(250) { Random.nextFloat() * 2 - 1 }
        private val starY = FloatArray(250) { Random.nextFloat() * 2 - 1 }
        private val starZ = FloatArray(250) { Random.nextFloat() }

        // пузырьки
        private val bx = FloatArray(45) { Random.nextFloat() }
        private val by = FloatArray(45) { Random.nextFloat() }
        private val br = FloatArray(45) { 0.01f + Random.nextFloat() * 0.04f }
        private val bs = FloatArray(45) { 0.02f + Random.nextFloat() * 0.06f }
        private val bp = FloatArray(45) { Random.nextFloat() * 6.28f }

        private val frameRunnable = Runnable { drawFrame() }

        private fun loadTheme() {
            theme = getSharedPreferences("prefs", Context.MODE_PRIVATE).getInt("theme", 0)
        }

        override fun onVisibilityChanged(v: Boolean) {
            visible = v
            if (v) {
                loadTheme()
                lastFrame = SystemClock.uptimeMillis()
                drawFrame()
            } else {
                handler.removeCallbacks(frameRunnable)
            }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            super.onSurfaceDestroyed(holder)
            visible = false
            handler.removeCallbacks(frameRunnable)
        }

        override fun onDestroy() {
            super.onDestroy()
            handler.removeCallbacks(frameRunnable)
        }

        private fun drawFrame() {
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas()
                if (canvas != null) {
                    val now = SystemClock.uptimeMillis()
                    val t = (now - startTime) / 1000f
                    val dt = ((now - lastFrame) / 1000f).coerceAtMost(0.1f)
                    lastFrame = now
                    when (theme) {
                        1 -> drawStars(canvas, t, dt)
                        2 -> drawBubbles(canvas, t, dt)
                        else -> drawWaves(canvas, t)
                    }
                }
            } finally {
                if (canvas != null) holder.unlockCanvasAndPost(canvas)
            }
            handler.removeCallbacks(frameRunnable)
            if (visible) handler.postDelayed(frameRunnable, 33) // ~30 FPS
        }

        private fun hsv(h: Float, s: Float, v: Float, a: Int = 255): Int =
            Color.HSVToColor(a, floatArrayOf(((h % 360f) + 360f) % 360f, s, v))

        // ---------- Волны ----------
        private fun drawWaves(c: Canvas, t: Float) {
            val w = c.width.toFloat()
            val h = c.height.toFloat()
            val hue = t * 8f
            paint.shader = LinearGradient(
                0f, 0f, 0f, h,
                hsv(hue, 0.7f, 0.45f), hsv(hue + 70f, 0.85f, 0.12f), Shader.TileMode.CLAMP
            )
            paint.style = Paint.Style.FILL
            c.drawRect(0f, 0f, w, h, paint)
            paint.shader = null
            for (i in 0 until 4) {
                path.reset()
                val baseY = h * (0.5f + 0.12f * i)
                val amp = h * 0.025f * (i + 1)
                path.moveTo(0f, h)
                var x = 0f
                while (x <= w + 12f) {
                    val y = baseY + sin(x / w * 2f * PI.toFloat() * (1f + i * 0.5f) + t * (0.8f + 0.35f * i)) * amp
                    path.lineTo(x, y)
                    x += 12f
                }
                path.lineTo(w, h)
                path.close()
                paint.color = hsv(hue + 40f * i + 20f, 0.6f, 0.95f, 90)
                c.drawPath(path, paint)
            }
        }

        // ---------- Звёзды ----------
        private fun drawStars(c: Canvas, t: Float, dt: Float) {
            val w = c.width.toFloat()
            val h = c.height.toFloat()
            c.drawColor(Color.rgb(3, 4, 18))
            val cx = w / 2f
            val cy = h / 2f
            paint.style = Paint.Style.FILL
            for (i in starX.indices) {
                starZ[i] -= dt * 0.35f
                if (starZ[i] <= 0.02f) {
                    starX[i] = Random.nextFloat() * 2 - 1
                    starY[i] = Random.nextFloat() * 2 - 1
                    starZ[i] = 1f
                }
                val sx = cx + starX[i] / starZ[i] * cx * 0.35f
                val sy = cy + starY[i] / starZ[i] * cy * 0.35f
                if (sx < 0 || sx > w || sy < 0 || sy > h) {
                    starZ[i] = 0f
                    continue
                }
                val b = ((1f - starZ[i]) * 255).toInt().coerceIn(40, 255)
                paint.color = Color.argb(255, b, b, 255)
                c.drawCircle(sx, sy, (1f - starZ[i]) * 4f + 0.6f, paint)
            }
        }

        // ---------- Пузырьки ----------
        private fun drawBubbles(c: Canvas, t: Float, dt: Float) {
            val w = c.width.toFloat()
            val h = c.height.toFloat()
            val hue = 190f + sin(t * 0.2f) * 40f
            paint.shader = LinearGradient(
                0f, 0f, 0f, h, hsv(hue, 0.6f, 0.30f), hsv(hue + 40f, 0.8f, 0.10f), Shader.TileMode.CLAMP
            )
            paint.style = Paint.Style.FILL
            c.drawRect(0f, 0f, w, h, paint)
            paint.shader = null
            for (i in bx.indices) {
                by[i] -= bs[i] * dt
                if (by[i] < -0.1f) {
                    by[i] = 1.1f
                    bx[i] = Random.nextFloat()
                }
                val x = (bx[i] + sin(t * 0.7f + bp[i]) * 0.03f) * w
                val y = by[i] * h
                val r = br[i] * w
                paint.style = Paint.Style.FILL
                paint.color = hsv(hue + i * 3f, 0.4f, 1f, 45)
                c.drawCircle(x, y, r, paint)
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 2f
                paint.color = hsv(hue + i * 3f, 0.2f, 1f, 130)
                c.drawCircle(x, y, r, paint)
            }
            paint.style = Paint.Style.FILL
        }
    }
}
